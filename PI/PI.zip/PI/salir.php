<?
 include("inc/conectar.php");
session_destroy();
?>
<script>
    window.location = "login.php";
</script>